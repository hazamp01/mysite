from django.shortcuts import render

# Create your views here.
from django.shortcuts import render,redirect
from django.http import HttpResponseRedirect
from django.http import HttpResponse, JsonResponse

from models import MusicNew,Songs,Persons,registration

def latest(request,get_id):
	print ' i am in boss',get_id
	print request.method

	check = MusicNew.objects.create(name='hits_2019',description='all hits of 2019',rank=1,status=1)

	music_data = MusicNew.objects.filter(id = get_id).values()
	# print music_data.query

	return render(request, "music/data.html",{'music_data':music_data})
	# pass


def latestSongs(request):
	songs_data = Songs.objects.filter().values('Songname','Genre','Artist','Date')
	return render(request, "music/data.html", {'music_data': songs_data})


def Personnames(request):
	person= Persons.objects.filter().values('personid','lastname','firstname','address','city','dateofbirth')
	return render(request, "music/data.html", {'music_data': person})

def username(request):
	print request.method

	if request.method == 'POST':
		firstname = request.POST.get('firstname')
		print 'firstname',firstname
		lastname = request.POST.get('lastname')
		print  'lastname',lastname
		return render(request, "music/data.html", {'music_data':{'firstname':firstname,'lastname':lastname}})
	else:
		return render(request, "music/username.html")


def login(request):
	print request.method
	if request.method == 'POST':
		Email = request.POST.get('email')
		print Email
		Password = request.POST.get('psw')
		print Password
		get_data = registration.objects.filter(Email=Email, Password=Password).values()
		# return HttpResponseRedirect('/music/login/')
		return render(request, "music/data.html", {'music_data': get_data})
	# return render(request, "music/registration.html")
	else:
		return render(request, "music/login.html")


def registrationform(request):
	print request.method
	if request.method == 'POST':
		Firstname = request.POST.get('firstname')
		print Firstname
		Lastname = request.POST.get('lastname')
		print Lastname
		Gender = request.POST.get('gender')
		print Gender
		Email = request.POST.get('email')
		print Email
		Password = request.POST.get('psw')
		print Password
		RepeatPassword = request.POST.get('psw_repeat')
		print RepeatPassword


		res = registration.objects.create(Firstname = Firstname ,Lastname=Lastname, Gender = Gender, Email = Email,Password= Password, RepeatPassword=RepeatPassword )
		get_id = res.id
		get_data = registration.objects.filter(id=get_id).values()
		return HttpResponseRedirect('/music/login/')
		# return render(request, "music/data.html", {'music_data': get_data})s
		# return render(request, "music/registration.html")
	else:
		return render(request, "music/registration.html")
