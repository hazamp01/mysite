#
#
# def mergeInOrder(nums_1, nums_2):
#   # return nums1 merged with nums2 in order
#   idx1 = 0
#   idx2 = 0
#   sorted_list = []
#   while idx1 < len(nums_1)and idx2 < len(nums_2):
#       if nums_1[idx1] < nums_2[idx2]:
#           sorted_list.append(nums_1[idx1])
#           idx1 += 1
#       elif nums_1[idx1] > nums_2[idx2]:
#           sorted_list.append(nums_2[idx2])
#           idx2 += 1
#       else:
#           sorted_list.append(nums_1[idx1])
#           sorted_list.append(nums_2[idx1])
#           idx1 += 1
#           idx2 += 1
#
#   if idx1 < len(nums_1):
#       sorted_list.extend(nums_1[idx1:])
#   if idx2 < len(nums_2):
#       sorted_list.extend(nums_2[idx2:])
#
#   return sorted_list
#
#
# print(mergeInOrder([1,3,5,7], [2,4,6,8,10,12,14]))
#
#
# class Order:
#     def saveToDb(self):
#         pass
#
#     @classmethod
#     def create(cls, param1, param2):
#        if param1 == 1:
#            return DealerOrder()
#        if param2 == 2:
#            return CustomerOrder()
#
# class DealerOrder(Order):
#     def __init__(self):
#         print("Cnstruction of DealerOrder")
#
#     def saveToDb(self):
#         pass
#
# class CustomerOrder(Order):
#     def __init__(self):
#         print("Cnstruction of CustomerOrder")
#
#     def saveToDb(self):
#         pass
#
# def createOrder(param1, param2):
#     if param1 == 1:
#         return DealerOrder()
#     elif param1 == 2 and param2 == 5:
#         return Order()
#     else:
#         return CustomerOrder()
#
#
# def foo():
#     x = createOrder(1, 6)
#     x.saveToDb()
#
#     x = createOrder(5, 10)
#     x.saveToDb()
#
#     x = Order.create(1, 2)
#     x.saveToDb()
#
# foo()

# class Solution(object):
#     def commonChars(self, A):
#         """
#         :type A: List[str]
#         :rtype: List[str]
#         """
#         _list = []
#         temp = A[0]
#         A.remove(A[0])
#         for char in temp:
#             total = 0
#             for text in A:
#                 if char in text: pass
#                 else: total += 1
#             if total == 0:
#                 for i in range(len(A)):
#                     A[i] = A[i].replace(char,"",1)
#                 _list.append(char)
#         return _list
# a = Solution()
# a.commonChars(["bella","label","roller"])

# def multiplexers ():
#
#     return [lambda n: index * n for index in range (4)]
#
# print [m (2) for m in multiplexers ()]
def fast (items= []):
    items.append (1)
    return items

print fast ()
print fast ()