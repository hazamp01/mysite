from django.db import models

# Create your models here.


class MusicNew(models.Model):
    id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=45)
    description = models.TextField()
    rank = models.IntegerField()
    status = models.IntegerField()

    class Meta:
        managed = False
        db_table = 'music_new'


class Songs(models.Model):
    Songname = models.CharField(max_length=45)
    Genre = models.CharField(max_length=45)
    Artist = models.CharField(max_length=45)
    Date = models.DateField()

    class Meta:
        managed = False
        db_table = 'Songs'


class Persons(models.Model):
    personid = models.IntegerField(db_column='PersonID', blank=True, null=True)  # Field name made lowercase.
    lastname = models.CharField(db_column='LastName', max_length=255, blank=True, null=True)  # Field name made lowercase.
    firstname = models.CharField(db_column='FirstName', max_length=255, blank=True, null=True)  # Field name made lowercase.
    address = models.CharField(db_column='Address', max_length=255, blank=True, null=True)  # Field name made lowercase.
    city = models.CharField(db_column='City', max_length=255, blank=True, null=True)  # Field name made lowercase.
    dateofbirth = models.DateField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'Persons'


class registration(models.Model):
    id = models.AutoField(primary_key=True)
    Firstname = models.CharField(db_column='Firstname', max_length=255, blank=True, null=True)  # Field name made lowercase.
    Lastname = models.CharField(db_column='LastName', max_length=255, blank=True,
                                null=True)  # Field name made lowercase.
    Gender = models.CharField(db_column='Gender', max_length=255, blank=True, null=True)  # Field name made lowercase.
    Email = models.CharField(db_column='Email', max_length=255, blank=True, null=True)  # Field name made lowercase.
    Password = models.CharField(db_column='Password', max_length=255, blank=True,
                                null=True)  # Field name made lowercase.
    RepeatPassword = models.CharField(db_column='RepeatPassword', max_length=255, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'registrationform'