# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
    ]

    operations = [
        migrations.CreateModel(
            name='MusicNew',
            fields=[
                ('id', models.AutoField(serialize=False, primary_key=True)),
                ('name', models.CharField(max_length=20)),
                ('description', models.TextField()),
                ('rank', models.IntegerField()),
                ('status', models.IntegerField()),
            ],
            options={
                'db_table': 'music_new',
                'managed': False,
            },
        ),
    ]
